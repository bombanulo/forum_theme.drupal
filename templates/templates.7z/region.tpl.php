<?php

/**
 * @file
 */

if ($content):
  print $content;
endif;
